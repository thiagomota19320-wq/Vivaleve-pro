const functions = require('firebase-functions');
const OpenAI = require('openai');

const client = new OpenAI({
  apiKey: functions.config().openai.key,
});

exports.chatCoach = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated');
  }

  const response = await client.chat.completions.create({
    model: 'gpt-4.1-mini',
    messages: [
      { role: 'system', content: 'Você é um coach fitness motivacional.' },
      { role: 'user', content: data.message }
    ],
  });

  return { reply: response.choices[0].message.content };
});
