# VivaLeve PRO

Projeto Flutter + Firebase com IA preparada para ativação futura.

## Rodar
Use Codemagic ou Flutter local para gerar APK.
